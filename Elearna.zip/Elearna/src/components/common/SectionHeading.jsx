
export default function SectionHeading({
  eyebrow,
  title,
  description,
  align = "left",
  className = "",
}) {
  const alignment =
    align === "center" ? "mx-auto text-center" : "text-left";

  return (
    <div className={`max-w-2xl ${alignment} ${className}`}>
      {eyebrow && (
        <p className="section-eyebrow">{eyebrow}</p>
      )}

      <h2 className="section-title">{title}</h2>

      {description && (
        <p className="section-description mt-4">
          {description}
        </p>
      )}
    </div>
  );
}
