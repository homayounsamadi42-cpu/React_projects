
import { Link } from "react-router-dom";
import { ChevronDown } from "lucide-react";

export default function NavDropdown({
  menu,
  isOpen,
  onToggle,
  onClose,
}) {
  const isMegaMenu = menu.label === "Courses";

  return (
    <div
      className="relative shrink-0"
      onMouseEnter={() => onToggle(true)}
      onMouseLeave={() => onToggle(false)}
    >
      <button
        type="button"
        aria-haspopup="true"
        aria-expanded={isOpen}
        onClick={() => onToggle(!isOpen)}
        onKeyDown={(event) => {
          if (event.key === "Escape") onClose();
        }}
        className="flex items-center gap-1.5 whitespace-nowrap py-8 text-[16px] font-medium text-white transition-colors duration-200 hover:text-[#FFB900] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#FFB900]"
      >
        {menu.label}

        <ChevronDown
          size={16}
          className={`shrink-0 transition-transform duration-200 ${
            isOpen ? "rotate-180" : ""
          }`}
        />
      </button>

      <div
        className={`absolute left-1/2 top-full z-50 -translate-x-1/2 overflow-hidden border-b-4 border-[#FFB900] bg-white text-[#172D32] shadow-xl transition-all duration-200 ${
          isMegaMenu ? "w-[min(760px,90vw)]" : "w-[220px]"
        } ${
          isOpen
            ? "visible translate-y-0 opacity-100"
            : "invisible translate-y-2 opacity-0"
        }`}
      >
        {isMegaMenu ? (
          <div className="grid grid-cols-2 gap-x-6 gap-y-5 p-6 md:grid-cols-3">
            {menu.children.map((item) => (
              <div key={item.label} className="min-w-0">
                {item.items ? (
                  <>
                    <Link
                      to={item.href}
                      onClick={onClose}
                      className="mb-2 block text-[15px] font-semibold text-[#172D32] transition-colors duration-200 hover:text-[#FFB900]"
                    >
                      {item.label}
                    </Link>

                    <ul className="space-y-2">
                      {item.items.map((subItem) => (
                        <li key={subItem.label}>
                          <Link
                            to={subItem.href}
                            onClick={onClose}
                            className="block text-sm leading-5 text-gray-600 transition-colors duration-200 hover:text-[#FFB900]"
                          >
                            {subItem.label}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </>
                ) : (
                  <Link
                    to={item.href}
                    onClick={onClose}
                    className="block text-[15px] font-medium text-[#172D32] transition-colors duration-200 hover:text-[#FFB900]"
                  >
                    {item.label}
                  </Link>
                )}
              </div>
            ))}
          </div>
        ) : (
          <ul className="py-2">
            {menu.children.map((item) => (
              <li key={item.label}>
                <Link
                  to={item.href}
                  onClick={onClose}
                  className="block px-5 py-2.5 text-[15px] text-[#172D32] transition-colors duration-200 hover:bg-gray-50 hover:text-[#FFB900]"
                >
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
