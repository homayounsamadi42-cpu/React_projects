
import { useState } from "react";
import { Link } from "react-router-dom";
import { ShoppingBag } from "lucide-react";

import { navigation } from "../../data/navigation";
import NavDropdown from "./NavDropdown";
import MobileMenu from "./MobileMenu";

export default function Navbar() {
  const [openMenu, setOpenMenu] = useState(null);

  const closeMenu = () => setOpenMenu(null);

  return (
    <header className="sticky top-0 z-50 w-full bg-[#062b30] text-white">
      <nav
        aria-label="Main navigation"
        className="flex min-h-[88px] w-full items-center justify-between gap-5 px-5 sm:px-8 lg:px-5 xl:px-8"
      >
        {/* Elearna logo */}
        <Link
          to="/"
          aria-label="Elearna home"
          className="flex shrink-0 items-center"
        >
          <span className="text-[30px] font-semibold tracking-[-1.8px] sm:text-[32px]">
            <span className="text-[#FFB900]">◉</span>lear
            <span className="text-[#FFB900]">n</span>a
          </span>
        </Link>

        {/* Desktop navigation */}
        <div className="hidden flex-1 items-center justify-center gap-5 lg:flex xl:gap-8">
          {navigation.map((menu) => (
            <NavDropdown
              key={menu.label}
              menu={menu}
              isOpen={openMenu === menu.label}
              onToggle={(nextOpen) =>
                setOpenMenu(nextOpen ? menu.label : null)
              }
              onClose={closeMenu}
            />
          ))}
        </div>

        {/* Right-side shopping bag and account links */}
        <div className="hidden shrink-0 items-center gap-5 lg:flex xl:gap-8">
          <Link
            to="/cart"
            aria-label="Shopping cart, 0 items"
            className="relative flex items-center bg-transparent p-1 text-white transition-colors hover:text-[#FFB900]"
          >
            <ShoppingBag size={24} strokeWidth={1.5} />

            <span className="absolute -right-2 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-[#FFB900] px-1 text-[11px] font-semibold text-[#172D32]">
              0
            </span>
          </Link>

          <div className="flex items-center gap-3 whitespace-nowrap text-[15px] font-medium xl:gap-4">
            <Link
              to="/login"
              className="bg-transparent text-white transition-colors hover:text-[#FFB900]"
            >
              Login
            </Link>

            <span className="h-6 w-px bg-white/70" />

            <Link
              to="/register"
              className="bg-transparent text-white transition-colors hover:text-[#FFB900]"
            >
              Register
            </Link>
          </div>
        </div>

        {/* Mobile navigation */}
        <div className="ml-auto lg:hidden">
          <MobileMenu navigation={navigation} />
        </div>
      </nav>
    </header>
  );
}
