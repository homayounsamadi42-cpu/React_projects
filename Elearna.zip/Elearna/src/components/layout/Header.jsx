
import { Link } from "react-router-dom";
import { GraduationCap } from "lucide-react";
import Button from "../common/Button.jsx";
import Navbar from "./Navbar.jsx";
import MobileMenu from "./MobileMenu.jsx";

export default function Header() {
  return (
    <header className="relative z-40 border-b border-slate-100 bg-white">
      <div className="container-site flex min-h-[82px] items-center justify-between gap-5">
        <Link
          to="/"
          aria-label="ElearnA home"
          className="flex shrink-0 items-center gap-2"
        >
          <span className="flex size-10 items-center justify-center rounded-xl bg-indigo-600 text-white">
            <GraduationCap size={25} />
          </span>

          <span className="text-xl font-extrabold tracking-tight text-slate-900">
            Elearn<span className="text-indigo-600">A</span>
          </span>
        </Link>

        <Navbar />

        <div className="hidden items-center gap-3 lg:flex">
          <Button href="/courses">Explore courses</Button>
        </div>

        <MobileMenu />
      </div>
    </header>
  );
}
