
import { Link } from "react-router-dom";
import { GraduationCap, Mail, MapPin, Phone } from "lucide-react";
import Container from "../common/Container.jsx";

const footerLinks = [
  { label: "Home One", href: "/" },
  { label: "Free Courses", href: "/courses" },
  { label: "Course Three", href: "/course-3" },
  { label: "Blog Two", href: "/blog-2" },
  { label: "Contact One", href: "/contact-1" },
];

export default function Footer() {
  return (
    <footer className="mt-16 bg-slate-950 text-slate-300">
      <Container className="py-14">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <Link
              to="/"
              className="inline-flex items-center gap-2 text-xl font-extrabold text-white"
            >
              <span className="flex size-10 items-center justify-center rounded-xl bg-indigo-600">
                <GraduationCap size={24} />
              </span>
              Elearn<span className="text-indigo-400">A</span>
            </Link>

            <p className="mt-5 max-w-xs text-sm leading-7 text-slate-400">
              Learn new skills, explore new interests, and move toward
              your goals with online education.
            </p>
          </div>

          <div>
            <h3 className="font-semibold text-white">Quick links</h3>
            <ul className="mt-5 space-y-3 text-sm">
              {footerLinks.map((link) => (
                <li key={link.href}>
                  <Link
                    to={link.href}
                    className="transition hover:text-white"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-white">Learning</h3>
            <ul className="mt-5 space-y-3 text-sm">
              <li>
                <Link to="/courses" className="hover:text-white">
                  Browse courses
                </Link>
              </li>
              <li>
                <Link to="/course-3" className="hover:text-white">
                  All courses
                </Link>
              </li>
              <li>
                <Link to="/blog-2" className="hover:text-white">
                  Latest articles
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-white">Get in touch</h3>
            <ul className="mt-5 space-y-4 text-sm text-slate-400">
              <li className="flex items-start gap-3">
                <Mail size={18} className="mt-0.5 shrink-0" />
                <span>Email us through our contact page</span>
              </li>
              <li className="flex items-start gap-3">
                <MapPin size={18} className="mt-0.5 shrink-0" />
                <span>Online learning, wherever you are</span>
              </li>
              <li className="flex items-start gap-3">
                <Phone size={18} className="mt-0.5 shrink-0" />
                <Link to="/contact-1" className="hover:text-white">
                  Contact our team
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 border-t border-white/10 pt-6 text-sm text-slate-500">
          <p>
            © {new Date().getFullYear()} ElearnA. All rights reserved.
          </p>
        </div>
      </Container>
    </footer>
  );
}
