
import { useState } from "react";
import { Link } from "react-router-dom";
import { Menu, X, ChevronDown } from "lucide-react";

export default function MobileMenu({ navigation = [] }) {
  const [isOpen, setIsOpen] = useState(false);
  const [expandedMenu, setExpandedMenu] = useState(null);

  const closeMenu = () => {
    setIsOpen(false);
    setExpandedMenu(null);
  };

  return (
    <div className="lg:hidden">
      <button
        type="button"
        aria-label={isOpen ? "Close navigation" : "Open navigation"}
        aria-expanded={isOpen}
        onClick={() => setIsOpen((open) => !open)}
        className="flex items-center justify-center rounded-none bg-transparent p-2 text-white transition-colors hover:bg-transparent hover:text-[#FFB900] focus-visible:outline-2 focus-visible:outline-[#FFB900]"
      >
        {isOpen ? <X size={27} /> : <Menu size={27} />}
      </button>

      {isOpen && (
        <div className="absolute left-0 right-0 top-full max-h-[80vh] overflow-y-auto border-b-4 border-[#FFB900] bg-[#062b30] px-5 py-4 shadow-xl">
          {navigation.map((item) => {
            const hasChildren = item.children?.length > 0;
            const isExpanded = expandedMenu === item.label;

            return (
              <div
                key={item.label}
                className="border-b border-white/10 last:border-b-0"
              >
                <div className="flex items-center justify-between">
                  <Link
                    to={item.href}
                    onClick={closeMenu}
                    className="py-3 text-base font-medium text-white transition-colors hover:text-[#FFB900]"
                  >
                    {item.label}
                  </Link>

                  {hasChildren && (
                    <button
                      type="button"
                      aria-label={`Toggle ${item.label} submenu`}
                      aria-expanded={isExpanded}
                      onClick={() =>
                        setExpandedMenu(isExpanded ? null : item.label)
                      }
                      className="bg-transparent p-2 text-white hover:bg-transparent hover:text-[#FFB900]"
                    >
                      <ChevronDown
                        size={18}
                        className={`transition-transform ${
                          isExpanded ? "rotate-180" : ""
                        }`}
                      />
                    </button>
                  )}
                </div>

                {hasChildren && isExpanded && (
                  <div className="mb-3 ml-3 border-l-2 border-[#FFB900] pl-4">
                    {item.children.map((child) => (
                      <div key={child.label}>
                        <Link
                          to={child.href}
                          onClick={closeMenu}
                          className="block py-2 text-sm text-white/85 transition-colors hover:text-[#FFB900]"
                        >
                          {child.label}
                        </Link>

                        {child.items?.map((subItem) => (
                          <Link
                            key={subItem.label}
                            to={subItem.href}
                            onClick={closeMenu}
                            className="block py-2 pl-3 text-sm text-white/70 transition-colors hover:text-[#FFB900]"
                          >
                            {subItem.label}
                          </Link>
                        ))}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}

          <div className="mt-4 flex items-center gap-4 border-t border-white/15 pt-4">
            <Link
              to="/cart"
              onClick={closeMenu}
              className="flex items-center gap-2 bg-transparent text-white hover:text-[#FFB900]"
            >
              <ShoppingBagIcon />
              Cart
            </Link>

            <Link
              to="/login"
              onClick={closeMenu}
              className="bg-transparent text-white hover:text-[#FFB900]"
            >
              Login
            </Link>

            <Link
              to="/register"
              onClick={closeMenu}
              className="bg-transparent text-white hover:text-[#FFB900]"
            >
              Register
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}

function ShoppingBagIcon() {
  return <span aria-hidden="true">♧</span>;
}
