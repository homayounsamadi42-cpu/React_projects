
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import Header from "./components/layout/Header.jsx";
import Footer from "./components/layout/Footer.jsx";
import HomePage from "./sections/home/HomePage.jsx";
import FreeCoursesPage from "./pages/FreeCoursesPage.jsx";
import CourseThreePage from "./pages/CourseThreePage.jsx";
import BlogTwoPage from "./pages/BlogTwoPage.jsx";
import ContactOnePage from "./pages/ContactOnePage.jsx";

function PreviewPage({ title }) {
  return (
    <main className="container-site min-h-[45vh] py-16">
      <p className="section-eyebrow">ElearnA</p>
      <h1 className="section-title">{title}</h1>
      <p className="section-description mt-4 max-w-2xl">
        This page will be implemented in a later step.
      </p>
      <Link
        to="/"
        className="mt-6 inline-flex rounded-lg bg-indigo-600 px-5 py-3 font-semibold text-white hover:bg-indigo-700"
      >
        Back to home
      </Link>
    </main>
  );
}

function AppShell() {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />

      <div className="flex-1">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/courses" element={<FreeCoursesPage />} />
          <Route path="/course-3" element={<CourseThreePage />} />
          <Route path="/blog-2" element={<BlogTwoPage />} />
          <Route path="/contact-1" element={<ContactOnePage />} />
          <Route
            path="*"
            element={<PreviewPage title="Page not found" />}
          />
        </Routes>
      </div>

      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AppShell />
    </BrowserRouter>
  );
}
