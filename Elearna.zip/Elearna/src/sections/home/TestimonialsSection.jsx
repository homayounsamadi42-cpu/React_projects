
import { Quote, Star } from "lucide-react";
import Container from "../../components/common/Container.jsx";
import SectionHeading from "../../components/common/SectionHeading.jsx";

const testimonials = [
  {
    name: "Emily Carter",
    role: "Web Development Student",
    image:
      "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=160&h=160&q=80",
    review:
      "The lessons were easy to follow, and I could study whenever it suited my schedule. I feel much more confident with the skills I've learned.",
  },
  {
    name: "Michael Brooks",
    role: "Design Student",
    image:
      "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=160&h=160&q=80",
    review:
      "I enjoyed the practical approach. The course structure helped me break down difficult topics and make steady progress.",
  },
  {
    name: "Sophia Williams",
    role: "Digital Marketing Student",
    image:
      "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?auto=format&fit=crop&w=160&h=160&q=80",
    review:
      "I liked being able to learn at my own pace. The material was organized clearly, and it was easy to return to lessons when needed.",
  },
];

export default function TestimonialsSection() {
  return (
    <section className="section-padding bg-white">
      <Container>
        <SectionHeading
          eyebrow="Student testimonials"
          title="What our learners say"
          description="Hear how a flexible learning experience can help students build confidence and keep moving toward their goals."
          align="center"
        />

        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((testimonial) => (
            <article
              key={testimonial.name}
              className="flex h-full flex-col rounded-2xl border border-slate-100 bg-white p-6 shadow-sm transition duration-200 hover:-translate-y-1 hover:shadow-xl hover:shadow-slate-900/5 sm:p-7"
            >
              <div className="flex items-center justify-between">
                <div className="flex gap-1 text-amber-400" aria-label="5 out of 5 stars">
                  {Array.from({ length: 5 }, (_, index) => (
                    <Star
                      key={index}
                      size={17}
                      fill="currentColor"
                      strokeWidth={1.5}
                    />
                  ))}
                </div>

                <Quote
                  size={30}
                  className="text-indigo-100"
                  fill="currentColor"
                />
              </div>

              <p className="mt-5 flex-1 text-sm leading-7 text-slate-600">
                “{testimonial.review}”
              </p>

              <div className="mt-6 flex items-center gap-3 border-t border-slate-100 pt-5">
                <img
                  src={testimonial.image}
                  alt=""
                  loading="lazy"
                  className="size-12 rounded-full object-cover"
                />

                <div>
                  <h3 className="font-bold text-slate-900">
                    {testimonial.name}
                  </h3>
                  <p className="mt-1 text-xs text-slate-500">
                    {testimonial.role}
                  </p>
                </div>
              </div>
            </article>
          ))}
        </div>
      </Container>
    </section>
  );
}
