
import {
  Award,
  BookOpenCheck,
  Clock3,
  GraduationCap,
  UsersRound,
} from "lucide-react";
import Container from "../../components/common/Container.jsx";

const benefits = [
  {
    icon: GraduationCap,
    title: "Expert instructors",
    description:
      "Learn from knowledgeable instructors who make complex topics easier to understand.",
    color: "bg-indigo-50 text-indigo-600",
  },
  {
    icon: BookOpenCheck,
    title: "Practical courses",
    description:
      "Build useful skills through structured lessons and learning activities.",
    color: "bg-emerald-50 text-emerald-600",
  },
  {
    icon: Clock3,
    title: "Learn at your pace",
    description:
      "Fit learning into your schedule and revisit lessons whenever you need.",
    color: "bg-amber-50 text-amber-600",
  },
  {
    icon: Award,
    title: "Grow your skills",
    description:
      "Work toward your personal and professional goals with focused learning.",
    color: "bg-pink-50 text-pink-600",
  },
];

export default function WhyChooseSection() {
  return (
    <section className="section-padding overflow-hidden bg-slate-50">
      <Container>
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
          <div className="relative mx-auto w-full max-w-lg">
            <div className="absolute -left-8 -top-8 size-40 rounded-full bg-indigo-100/70 blur-2xl" />

            <div className="relative overflow-hidden rounded-3xl bg-white p-3 shadow-xl shadow-slate-900/5">
              <img
                src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1000&q=85"
                alt="Students learning and working together"
                loading="lazy"
                className="aspect-[4/5] w-full rounded-2xl object-cover"
              />
            </div>

            <div className="absolute -bottom-5 -right-3 max-w-[230px] rounded-2xl border border-slate-100 bg-white p-5 shadow-xl sm:-right-6">
              <div className="flex items-center gap-3">
                <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600">
                  <UsersRound size={23} />
                </span>
                <div>
                  <p className="text-xl font-extrabold text-slate-900">
                    Learn together
                  </p>
                  <p className="mt-1 text-xs text-slate-500">
                    Build skills for your future
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="pt-4 lg:pt-0">
            <p className="section-eyebrow">Why choose ElearnA</p>

            <h2 className="section-title">
              A better way to learn, grow, and achieve your goals
            </h2>

            <p className="section-description mt-5">
              Take control of your learning journey with flexible online
              education, practical lessons, and support for your next step.
            </p>

            <div className="mt-8 grid gap-6 sm:grid-cols-2">
              {benefits.map((benefit) => {
                const Icon = benefit.icon;

                return (
                  <div key={benefit.title} className="flex items-start gap-3">
                    <span
                      className={`flex size-11 shrink-0 items-center justify-center rounded-xl ${benefit.color}`}
                    >
                      <Icon size={22} />
                    </span>

                    <div>
                      <h3 className="font-bold text-slate-900">
                        {benefit.title}
                      </h3>
                      <p className="mt-2 text-sm leading-6 text-slate-500">
                        {benefit.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
