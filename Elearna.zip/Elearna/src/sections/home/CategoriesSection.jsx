
import {
  Code2,
  Palette,
  BriefcaseBusiness,
  Megaphone,
  Camera,
  Music2,
  HeartPulse,
  Languages,
  ArrowUpRight,
} from "lucide-react";
import Container from "../../components/common/Container.jsx";
import SectionHeading from "../../components/common/SectionHeading.jsx";

const categories = [
  {
    title: "Development",
    courses: "120+ Courses",
    icon: Code2,
    color: "bg-blue-50 text-blue-600",
  },
  {
    title: "Design",
    courses: "85+ Courses",
    icon: Palette,
    color: "bg-pink-50 text-pink-600",
  },
  {
    title: "Business",
    courses: "95+ Courses",
    icon: BriefcaseBusiness,
    color: "bg-amber-50 text-amber-600",
  },
  {
    title: "Marketing",
    courses: "70+ Courses",
    icon: Megaphone,
    color: "bg-purple-50 text-purple-600",
  },
  {
    title: "Photography",
    courses: "45+ Courses",
    icon: Camera,
    color: "bg-emerald-50 text-emerald-600",
  },
  {
    title: "Music",
    courses: "60+ Courses",
    icon: Music2,
    color: "bg-orange-50 text-orange-600",
  },
  {
    title: "Health & Fitness",
    courses: "55+ Courses",
    icon: HeartPulse,
    color: "bg-rose-50 text-rose-600",
  },
  {
    title: "Languages",
    courses: "40+ Courses",
    icon: Languages,
    color: "bg-cyan-50 text-cyan-600",
  },
];

export default function CategoriesSection() {
  return (
    <section className="section-padding bg-slate-50">
      <Container>
        <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
          <SectionHeading
            eyebrow="Explore categories"
            title="Browse our top categories"
            description="Discover courses across popular subjects and find the skills you want to develop."
          />

          <a
            href="/courses"
            className="inline-flex shrink-0 items-center gap-2 text-sm font-semibold text-indigo-600 transition hover:text-indigo-800"
          >
            View all categories
            <ArrowUpRight size={18} />
          </a>
        </div>

        <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {categories.map((category) => {
            const Icon = category.icon;

            return (
              <a
                key={category.title}
                href="/courses"
                className="group flex items-center gap-4 rounded-2xl border border-slate-100 bg-white p-5 transition duration-200 hover:-translate-y-1 hover:border-indigo-100 hover:shadow-xl hover:shadow-slate-900/5"
              >
                <span
                  className={`flex size-14 shrink-0 items-center justify-center rounded-xl ${category.color}`}
                >
                  <Icon size={26} strokeWidth={1.8} />
                </span>

                <span className="min-w-0 flex-1">
                  <span className="block font-bold text-slate-900 transition group-hover:text-indigo-600">
                    {category.title}
                  </span>
                  <span className="mt-1 block text-sm text-slate-500">
                    {category.courses}
                  </span>
                </span>

                <ArrowUpRight
                  size={18}
                  className="shrink-0 text-slate-300 transition group-hover:text-indigo-600"
                />
              </a>
            );
          })}
        </div>
      </Container>
    </section>
  );
}
