
import { Link } from "react-router-dom";
import { ArrowRight, Award } from "lucide-react";

export default function HeroSection() {
  return (
    <section className="relative isolate min-h-[760px] overflow-hidden bg-[#062b30] text-white lg:min-h-[850px]">
      {/* Background texture and decorative lighting */}
      <div
        aria-hidden="true"
        className="absolute inset-0 -z-10"
        style={{
          backgroundImage: `
            radial-gradient(circle at 18% 40%, rgba(30, 76, 81, 0.45), transparent 38%),
            radial-gradient(circle at 82% 30%, rgba(0, 0, 0, 0.12), transparent 35%),
            repeating-linear-gradient(125deg, transparent 0px, transparent 4px, rgba(255,255,255,0.012) 5px, transparent 6px)
          `,
        }}
      />

      <div className="mx-auto grid min-h-[760px] max-w-[1440px] items-center gap-8 px-5 pb-12 pt-28 sm:px-8 lg:min-h-[850px] lg:grid-cols-2 lg:gap-12 lg:px-12 lg:pb-0 lg:pt-20">
        {/* Student image */}
        <div className="relative flex min-h-[410px] items-end justify-center sm:min-h-[500px] lg:h-full lg:min-h-[700px]">
          <div className="absolute bottom-[8%] left-[2%] h-36 w-36 rounded-full border-[16px] border-blue-600 sm:left-[8%]" />

          <div className="absolute bottom-[12%] left-[5%] h-28 w-28 rotate-45 bg-[#FFB900]/70 sm:left-[12%]" />

          <div className="absolute right-[5%] top-[32%] h-5 w-5 rounded-full bg-[#FFB900]" />

          <img
            src="/src/assets/hero.png"
            alt="Student ready to learn online"
            className="relative z-10 max-h-[650px] w-full max-w-[570px] object-contain object-bottom lg:absolute lg:bottom-0 lg:left-1/2 lg:max-w-[650px] lg:-translate-x-1/2"
          />

          {/* Achievement badge */}
          <div className="absolute bottom-[7%] left-0 z-20 flex items-center gap-4 rounded-xl bg-[#f5faf4] px-5 py-4 text-[#183439] shadow-lg sm:bottom-[9%] sm:left-[5%] sm:px-6">
            <Award size={43} strokeWidth={1.4} />
            <div>
              <p className="text-[22px] font-bold leading-tight">125+</p>
              <p className="mt-1 text-sm sm:text-base">Achievement awards</p>
            </div>
          </div>
        </div>

        {/* Hero copy */}
        <div className="relative z-20 mx-auto w-full max-w-[600px] py-8 lg:mx-0 lg:py-0">
          <p className="mb-5 text-sm font-semibold uppercase tracking-wide sm:text-base">
            Online Learning
          </p>

          <h1 className="text-[42px] font-semibold leading-[1.12] tracking-[-1.8px] sm:text-5xl lg:text-[58px] xl:text-[64px]">
            More then{" "}
            <span className="text-[#FFB900]">25000+</span>{" "}
            education courses online
          </h1>

          <p className="mt-6 max-w-[540px] text-[15px] leading-8 text-white/90 sm:text-base">
            Lorem ipsum dolor sit amet consectetur. Gravida enim risus
            sollicitudin mauris tincidunt commodo ornare.
          </p>

          <Link
            to="/courses"
            className="mt-8 inline-flex min-w-[194px] items-center justify-center gap-3 rounded-[4px] border border-white/20 px-7 py-4 text-[16px] font-medium transition-colors duration-200 hover:border-[#FFB900] hover:bg-[#FFB900] hover:text-[#172D32]"
          >
            Get Started
            <ArrowRight size={18} />
          </Link>
        </div>
      </div>
    </section>
  );
}
