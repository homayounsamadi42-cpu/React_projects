
import HeroSection from "./HeroSection.jsx";
import CategoriesSection from "./CategoriesSection.jsx";
import FeaturedCoursesSection from "./FeaturedCoursesSection.jsx";
import WhyChooseSection from "./WhyChooseSection.jsx";
import TestimonialsSection from "./TestimonialsSection.jsx";

export default function HomePage() {
  return (
    <main>
      <HeroSection />
      <CategoriesSection />
      <FeaturedCoursesSection />
      <WhyChooseSection />
      <TestimonialsSection />

      {/* More homepage sections will be added in the next steps. */}
    </main>
  );
}
