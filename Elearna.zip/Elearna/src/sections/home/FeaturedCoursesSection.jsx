
import { ArrowRight, Clock3, Star, Users } from "lucide-react";
import { Link } from "react-router-dom";
import Container from "../../components/common/Container.jsx";
import SectionHeading from "../../components/common/SectionHeading.jsx";

const courses = [
  {
    title: "Complete Web Development Bootcamp",
    category: "Development",
    instructor: "Alex Morgan",
    rating: "4.9",
    reviews: "120",
    lessons: "24 Lessons",
    students: "1,240 Students",
    price: "$49.00",
    oldPrice: "$89.00",
    image:
      "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=900&q=80",
    color: "bg-blue-50 text-blue-700",
  },
  {
    title: "UI/UX Design: From Beginner to Pro",
    category: "Design",
    instructor: "Sarah Johnson",
    rating: "4.8",
    reviews: "98",
    lessons: "18 Lessons",
    students: "860 Students",
    price: "$39.00",
    oldPrice: "$69.00",
    image:
      "https://images.unsplash.com/photo-1561070791-2526d30994b5?auto=format&fit=crop&w=900&q=80",
    color: "bg-pink-50 text-pink-700",
  },
  {
    title: "Digital Marketing Masterclass",
    category: "Marketing",
    instructor: "David Wilson",
    rating: "4.9",
    reviews: "145",
    lessons: "21 Lessons",
    students: "1,050 Students",
    price: "$45.00",
    oldPrice: "$79.00",
    image:
      "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=900&q=80",
    color: "bg-purple-50 text-purple-700",
  },
];

export default function FeaturedCoursesSection() {
  return (
    <section className="section-padding bg-white">
      <Container>
        <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
          <SectionHeading
            eyebrow="Popular courses"
            title="Our top online courses"
            description="Explore practical courses designed to help you build skills and take the next step in your learning journey."
          />

          <Link
            to="/course-3"
            className="inline-flex shrink-0 items-center gap-2 text-sm font-semibold text-indigo-600 transition hover:text-indigo-800"
          >
            View all courses
            <ArrowRight size={18} />
          </Link>
        </div>

        <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {courses.map((course) => (
            <article
              key={course.title}
              className="group overflow-hidden rounded-2xl border border-slate-100 bg-white transition duration-200 hover:-translate-y-1 hover:shadow-xl hover:shadow-slate-900/5"
            >
              <div className="relative overflow-hidden">
                <img
                  src={course.image}
                  alt={course.title}
                  loading="lazy"
                  className="aspect-[16/10] w-full object-cover transition duration-500 group-hover:scale-105"
                />

                <span
                  className={`absolute left-4 top-4 rounded-full px-3 py-1.5 text-xs font-semibold ${course.color}`}
                >
                  {course.category}
                </span>
              </div>

              <div className="p-5">
                <div className="flex items-center gap-2 text-sm">
                  <span className="inline-flex items-center gap-1 font-semibold text-amber-500">
                    <Star size={16} fill="currentColor" />
                    {course.rating}
                  </span>
                  <span className="text-slate-400">
                    ({course.reviews} reviews)
                  </span>
                </div>

                <h3 className="mt-3 min-h-14 text-lg font-bold leading-7 text-slate-900 transition group-hover:text-indigo-600">
                  {course.title}
                </h3>

                <p className="mt-2 text-sm text-slate-500">
                  By {course.instructor}
                </p>

                <div className="mt-5 flex flex-wrap gap-x-4 gap-y-2 border-b border-slate-100 pb-5 text-xs text-slate-500">
                  <span className="inline-flex items-center gap-1.5">
                    <Clock3 size={15} />
                    {course.lessons}
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <Users size={15} />
                    {course.students}
                  </span>
                </div>

                <div className="flex items-center justify-between gap-3 pt-5">
                  <div className="flex items-center gap-2">
                    <span className="text-xl font-extrabold text-slate-900">
                      {course.price}
                    </span>
                    <span className="text-sm text-slate-400 line-through">
                      {course.oldPrice}
                    </span>
                  </div>

                  <Link
                    to="/course-3"
                    className="inline-flex items-center gap-1 text-sm font-semibold text-indigo-600 hover:text-indigo-800"
                  >
                    Details
                    <ArrowRight size={16} />
                  </Link>
                </div>
              </div>
            </article>
          ))}
        </div>

        <div className="mt-10 text-center">
          <Link
            to="/courses"
            className="inline-flex items-center gap-2 rounded-lg border border-slate-200 px-6 py-3 font-semibold text-slate-800 transition hover:border-indigo-200 hover:bg-indigo-50"
          >
            Explore all courses
            <ArrowRight size={18} />
          </Link>
        </div>
      </Container>
    </section>
  );
}
