
import { useState } from "react";
import {
  ArrowRight,
  CheckCircle2,
  Clock3,
  Mail,
  MapPin,
  MessageSquare,
  Phone,
  Send,
} from "lucide-react";
import Container from "../components/common/Container.jsx";

const contactDetails = [
  {
    icon: Mail,
    title: "Email us",
    description: "Our team is happy to help.",
    value: "hello@ele arna.com".replace(" ", ""),
    href: "mailto:hello@elearna.com",
  },
  {
    icon: Phone,
    title: "Call us",
    description: "Speak with our support team.",
    value: "+1 (555) 123-4567",
    href: "tel:+15551234567",
  },
  {
    icon: MapPin,
    title: "Visit us",
    description: "Our team works to support learners everywhere.",
    value: "Online learning, worldwide",
    href: null,
  },
];

export default function ContactOnePage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "General inquiry",
    message: "",
  });

  const [submitted, setSubmitted] = useState(false);

  function handleChange(event) {
    const { name, value } = event.target;

    setFormData((current) => ({
      ...current,
      [name]: value,
    }));

    if (submitted) {
      setSubmitted(false);
    }
  }

  function handleSubmit(event) {
    event.preventDefault();
    setSubmitted(true);
  }

  return (
    <main>
      <section className="bg-slate-50 py-16 sm:py-20 lg:py-24">
        <Container>
          <div className="mx-auto max-w-3xl text-center">
            <p className="section-eyebrow">We would love to hear from you</p>

            <h1 className="section-title">
              Let's start a conversation
            </h1>

            <p className="section-description mx-auto mt-4 max-w-2xl">
              Have a question about our courses or need help with your
              learning journey? Send us a message and let us know how
              we can help.
            </p>
          </div>
        </Container>
      </section>

      <section className="section-padding bg-white">
        <Container>
          <div className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:gap-16">
            <div>
              <p className="section-eyebrow">Contact information</p>

              <h2 className="text-2xl font-bold leading-tight tracking-tight text-slate-900 sm:text-3xl">
                We're here to help you succeed
              </h2>

              <p className="mt-4 text-sm leading-7 text-slate-500">
                Whether you're exploring courses, need technical support,
                or want to work with us, reach out using the details below.
              </p>

              <div className="mt-8 space-y-4">
                {contactDetails.map((item) => {
                  const Icon = item.icon;

                  return (
                    <div
                      key={item.title}
                      className="flex gap-4 rounded-2xl border border-slate-100 p-5 transition hover:border-indigo-100 hover:bg-slate-50"
                    >
                      <div className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600">
                        <Icon size={22} />
                      </div>

                      <div className="min-w-0">
                        <h3 className="font-bold text-slate-900">
                          {item.title}
                        </h3>

                        <p className="mt-1 text-sm leading-6 text-slate-500">
                          {item.description}
                        </p>

                        {item.href ? (
                          <a
                            href={item.href}
                            className="mt-2 inline-block break-words text-sm font-semibold text-indigo-600 hover:text-indigo-800"
                          >
                            {item.value}
                          </a>
                        ) : (
                          <p className="mt-2 text-sm font-semibold text-indigo-600">
                            {item.value}
                          </p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="mt-6 flex gap-3 rounded-2xl bg-slate-50 p-5">
                <Clock3
                  size={21}
                  className="mt-0.5 shrink-0 text-indigo-600"
                />

                <div>
                  <h3 className="font-bold text-slate-900">
                    Our support team
                  </h3>

                  <p className="mt-1 text-sm leading-6 text-slate-500">
                    Send us a message at any time. We aim to respond
                    as soon as possible during our support hours.
                  </p>
                </div>
              </div>
            </div>

            <div className="rounded-3xl border border-slate-100 bg-white p-6 shadow-sm sm:p-8 lg:p-10">
              {submitted ? (
                <div
                  role="status"
                  className="flex min-h-[420px] flex-col items-center justify-center text-center"
                >
                  <div className="flex size-16 items-center justify-center rounded-full bg-emerald-50 text-emerald-600">
                    <CheckCircle2 size={34} />
                  </div>

                  <h2 className="mt-6 text-2xl font-bold text-slate-900">
                    Thanks for reaching out!
                  </h2>

                  <p className="mt-3 max-w-sm text-sm leading-7 text-slate-500">
                    Your form passed browser validation. This demo does not
                    send your message to a server or email inbox yet.
                  </p>

                  <button
                    type="button"
                    onClick={() => {
                      setFormData({
                        name: "",
                        email: "",
                        subject: "General inquiry",
                        message: "",
                      });
                      setSubmitted(false);
                    }}
                    className="mt-7 rounded-lg bg-indigo-600 px-5 py-3 text-sm font-semibold text-white transition hover:bg-indigo-700"
                  >
                    Send another message
                  </button>
                </div>
              ) : (
                <>
                  <div className="mb-7">
                    <div className="flex size-12 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600">
                      <MessageSquare size={23} />
                    </div>

                    <h2 className="mt-5 text-2xl font-bold text-slate-900">
                      Send us a message
                    </h2>

                    <p className="mt-2 text-sm leading-6 text-slate-500">
                      Fill out the form below and tell us what you need.
                    </p>
                  </div>

                  <form onSubmit={handleSubmit} className="space-y-5">
                    <div className="grid gap-5 sm:grid-cols-2">
                      <div>
                        <label
                          htmlFor="contact-name"
                          className="mb-2 block text-sm font-semibold text-slate-700"
                        >
                          Full name
                        </label>

                        <input
                          id="contact-name"
                          name="name"
                          type="text"
                          autoComplete="name"
                          value={formData.name}
                          onChange={handleChange}
                          placeholder="Your name"
                          required
                          className="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10"
                        />
                      </div>

                      <div>
                        <label
                          htmlFor="contact-email"
                          className="mb-2 block text-sm font-semibold text-slate-700"
                        >
                          Email address
                        </label>

                        <input
                          id="contact-email"
                          name="email"
                          type="email"
                          autoComplete="email"
                          value={formData.email}
                          onChange={handleChange}
                          placeholder="you@example.com"
                          required
                          className="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10"
                        />
                      </div>
                    </div>

                    <div>
                      <label
                        htmlFor="contact-subject"
                        className="mb-2 block text-sm font-semibold text-slate-700"
                      >
                        What can we help with?
                      </label>

                      <select
                        id="contact-subject"
                        name="subject"
                        value={formData.subject}
                        onChange={handleChange}
                        className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-800 outline-none transition focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10"
                      >
                        <option>General inquiry</option>
                        <option>Course information</option>
                        <option>Technical support</option>
                        <option>Partnership opportunity</option>
                        <option>Other</option>
                      </select>
                    </div>

                    <div>
                      <label
                        htmlFor="contact-message"
                        className="mb-2 block text-sm font-semibold text-slate-700"
                      >
                        Your message
                      </label>

                      <textarea
                        id="contact-message"
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        placeholder="How can we help you?"
                        rows={5}
                        required
                        className="w-full resize-y rounded-xl border border-slate-200 px-4 py-3 text-sm leading-6 text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10"
                      />
                    </div>

                    <button
                      type="submit"
                      className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-indigo-600 px-6 py-3.5 text-sm font-semibold text-white transition hover:bg-indigo-700 focus:outline-none focus:ring-4 focus:ring-indigo-500/20 sm:w-auto"
                    >
                      Send message
                      <Send size={17} />
                    </button>

                    <p className="text-xs leading-5 text-slate-400">
                      Demo form only. Your message is not transmitted or
                      stored by a backend.
                    </p>
                  </form>
                </>
              )}
            </div>
          </div>
        </Container>
      </section>

      <section className="bg-slate-50 py-14">
        <Container>
          <div className="mx-auto max-w-3xl text-center">
            <p className="section-eyebrow">Your next step starts here</p>

            <h2 className="text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
              Ready to explore new skills?
            </h2>

            <p className="mx-auto mt-3 max-w-xl text-sm leading-7 text-slate-500">
              Explore our course catalog and find a learning opportunity
              that fits your goals.
            </p>

            <a
              href="/courses"
              className="mt-6 inline-flex items-center gap-2 rounded-lg bg-indigo-600 px-6 py-3 font-semibold text-white transition hover:bg-indigo-700"
            >
              Explore courses
              <ArrowRight size={17} />
            </a>
          </div>
        </Container>
      </section>
    </main>
  );
}
