
import { useMemo, useState } from "react";
import { ArrowRight, Clock3, Search, Star, Users } from "lucide-react";
import { Link } from "react-router-dom";
import Container from "../components/common/Container.jsx";
import SectionHeading from "../components/common/SectionHeading.jsx";

const courses = [
  {
    title: "Complete Web Development Bootcamp",
    category: "Development",
    instructor: "Alex Morgan",
    rating: 4.9,
    lessons: 24,
    students: 1240,
    price: "$49",
    image:
      "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=900&q=80",
  },
  {
    title: "UI/UX Design: From Beginner to Pro",
    category: "Design",
    instructor: "Sarah Johnson",
    rating: 4.8,
    lessons: 18,
    students: 860,
    price: "$39",
    image:
      "https://images.unsplash.com/photo-1561070791-2526d30994b5?auto=format&fit=crop&w=900&q=80",
  },
  {
    title: "Digital Marketing Masterclass",
    category: "Marketing",
    instructor: "David Wilson",
    rating: 4.9,
    lessons: 21,
    students: 1050,
    price: "$45",
    image:
      "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=900&q=80",
  },
  {
    title: "Modern JavaScript for Beginners",
    category: "Development",
    instructor: "James Parker",
    rating: 4.7,
    lessons: 16,
    students: 730,
    price: "$29",
    image:
      "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=900&q=80",
  },
  {
    title: "Creative Graphic Design Essentials",
    category: "Design",
    instructor: "Olivia Bennett",
    rating: 4.8,
    lessons: 20,
    students: 920,
    price: "$35",
    image:
      "https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=900&q=80",
  },
  {
    title: "Business Strategy Fundamentals",
    category: "Business",
    instructor: "Daniel Lewis",
    rating: 4.7,
    lessons: 14,
    students: 640,
    price: "$32",
    image:
      "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=900&q=80",
  },
];

const categories = [
  "All Courses",
  "Development",
  "Design",
  "Marketing",
  "Business",
];

export default function FreeCoursesPage() {
  const [activeCategory, setActiveCategory] = useState("All Courses");
  const [searchTerm, setSearchTerm] = useState("");

  const filteredCourses = useMemo(() => {
    const query = searchTerm.trim().toLowerCase();

    return courses.filter((course) => {
      const matchesCategory =
        activeCategory === "All Courses" ||
        course.category === activeCategory;

      const matchesSearch =
        course.title.toLowerCase().includes(query) ||
        course.category.toLowerCase().includes(query) ||
        course.instructor.toLowerCase().includes(query);

      return matchesCategory && matchesSearch;
    });
  }, [activeCategory, searchTerm]);

  return (
    <main>
      <section className="bg-slate-50 py-16 sm:py-20">
        <Container>
          <div className="mx-auto max-w-3xl text-center">
            <p className="section-eyebrow">Expand your knowledge</p>
            <h1 className="section-title">
              Explore our online courses
            </h1>
            <p className="section-description mt-4">
              Find your next learning opportunity, explore new subjects,
              and develop skills for your personal and professional goals.
            </p>

            <div className="mx-auto mt-8 flex max-w-xl items-center gap-3 rounded-xl border border-slate-200 bg-white px-4 py-3 shadow-sm">
              <Search
                size={20}
                className="shrink-0 text-slate-400"
              />
              <input
                type="search"
                value={searchTerm}
                onChange={(event) => setSearchTerm(event.target.value)}
                placeholder="Search courses or instructors..."
                aria-label="Search courses or instructors"
                className="w-full bg-transparent text-sm text-slate-800 outline-none placeholder:text-slate-400"
              />
            </div>
          </div>
        </Container>
      </section>

      <section className="section-padding bg-white">
        <Container>
          <SectionHeading
            eyebrow="Course catalog"
            title="Find the right course for you"
            description="Browse subjects and choose a course that matches your interests."
          />

          <div
            className="mt-8 flex flex-wrap gap-3"
            aria-label="Filter courses by category"
          >
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                onClick={() => setActiveCategory(category)}
                aria-pressed={activeCategory === category}
                className={`rounded-full border px-5 py-2.5 text-sm font-semibold transition ${
                  activeCategory === category
                    ? "border-indigo-600 bg-indigo-600 text-white"
                    : "border-slate-200 bg-white text-slate-600 hover:border-indigo-300 hover:text-indigo-600"
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          <div className="mt-8 flex items-center justify-between gap-4">
            <p className="text-sm text-slate-500">
              Showing {filteredCourses.length}{" "}
              {filteredCourses.length === 1 ? "course" : "courses"}
            </p>

            {(searchTerm || activeCategory !== "All Courses") && (
              <button
                type="button"
                onClick={() => {
                  setSearchTerm("");
                  setActiveCategory("All Courses");
                }}
                className="text-sm font-semibold text-indigo-600 hover:text-indigo-800"
              >
                Clear filters
              </button>
            )}
          </div>

          {filteredCourses.length > 0 ? (
            <div className="mt-5 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {filteredCourses.map((course) => (
                <article
                  key={course.title}
                  className="group overflow-hidden rounded-2xl border border-slate-100 bg-white transition duration-200 hover:-translate-y-1 hover:shadow-xl hover:shadow-slate-900/5"
                >
                  <div className="overflow-hidden">
                    <img
                      src={course.image}
                      alt={course.title}
                      loading="lazy"
                      className="aspect-[16/10] w-full object-cover transition duration-500 group-hover:scale-105"
                    />
                  </div>

                  <div className="p-5">
                    <span className="inline-block rounded-full bg-indigo-50 px-3 py-1.5 text-xs font-semibold text-indigo-700">
                      {course.category}
                    </span>

                    <div className="mt-4 flex items-center gap-1.5 text-sm">
                      <Star
                        size={16}
                        fill="currentColor"
                        className="text-amber-400"
                      />
                      <span className="font-semibold text-slate-800">
                        {course.rating}
                      </span>
                      <span className="text-slate-400">
                        course rating
                      </span>
                    </div>

                    <h2 className="mt-3 min-h-14 text-lg font-bold leading-7 text-slate-900 group-hover:text-indigo-600">
                      {course.title}
                    </h2>

                    <p className="mt-2 text-sm text-slate-500">
                      By {course.instructor}
                    </p>

                    <div className="mt-5 flex flex-wrap gap-x-4 gap-y-2 border-b border-slate-100 pb-5 text-xs text-slate-500">
                      <span className="inline-flex items-center gap-1.5">
                        <Clock3 size={15} />
                        {course.lessons} lessons
                      </span>
                      <span className="inline-flex items-center gap-1.5">
                        <Users size={15} />
                        {course.students.toLocaleString()} students
                      </span>
                    </div>

                    <div className="flex items-center justify-between gap-3 pt-5">
                      <span className="text-xl font-extrabold text-slate-900">
                        {course.price}
                      </span>

                      <Link
                        to="/course-3"
                        className="inline-flex items-center gap-2 text-sm font-semibold text-indigo-600 hover:text-indigo-800"
                      >
                        View details
                        <ArrowRight size={16} />
                      </Link>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <div className="mt-8 rounded-2xl border border-dashed border-slate-200 px-6 py-16 text-center">
              <h2 className="text-lg font-bold text-slate-900">
                No courses found
              </h2>
              <p className="mt-2 text-sm text-slate-500">
                Try a different search term or select another category.
              </p>
              <button
                type="button"
                onClick={() => {
                  setSearchTerm("");
                  setActiveCategory("All Courses");
                }}
                className="mt-5 rounded-lg bg-indigo-600 px-5 py-3 text-sm font-semibold text-white hover:bg-indigo-700"
              >
                Show all courses
              </button>
            </div>
          )}
        </Container>
      </section>
    </main>
  );
}
