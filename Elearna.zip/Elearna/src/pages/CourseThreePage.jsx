
import { useMemo, useState } from "react";
import {
  ArrowRight,
  BookOpen,
  Clock3,
  Search,
  SlidersHorizontal,
  Star,
  Users,
} from "lucide-react";
import { Link } from "react-router-dom";
import Container from "../components/common/Container.jsx";
import SectionHeading from "../components/common/SectionHeading.jsx";

const courses = [
  {
    id: 1,
    title: "Complete Web Development Bootcamp",
    category: "Development",
    instructor: "Alex Morgan",
    rating: 4.9,
    lessons: 24,
    students: 1240,
    price: 49,
    level: "Beginner",
    image:
      "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=900&q=80",
  },
  {
    id: 2,
    title: "UI/UX Design: From Beginner to Pro",
    category: "Design",
    instructor: "Sarah Johnson",
    rating: 4.8,
    lessons: 18,
    students: 860,
    price: 39,
    level: "Beginner",
    image:
      "https://images.unsplash.com/photo-1561070791-2526d30994b5?auto=format&fit=crop&w=900&q=80",
  },
  {
    id: 3,
    title: "Digital Marketing Masterclass",
    category: "Marketing",
    instructor: "David Wilson",
    rating: 4.9,
    lessons: 21,
    students: 1050,
    price: 45,
    level: "Intermediate",
    image:
      "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=900&q=80",
  },
  {
    id: 4,
    title: "Modern JavaScript for Beginners",
    category: "Development",
    instructor: "James Parker",
    rating: 4.7,
    lessons: 16,
    students: 730,
    price: 29,
    level: "Beginner",
    image:
      "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=900&q=80",
  },
  {
    id: 5,
    title: "Creative Graphic Design Essentials",
    category: "Design",
    instructor: "Olivia Bennett",
    rating: 4.8,
    lessons: 20,
    students: 920,
    price: 35,
    level: "Intermediate",
    image:
      "https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=900&q=80",
  },
  {
    id: 6,
    title: "Business Strategy Fundamentals",
    category: "Business",
    instructor: "Daniel Lewis",
    rating: 4.7,
    lessons: 14,
    students: 640,
    price: 32,
    level: "Beginner",
    image:
      "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=900&q=80",
  },
];

const categories = [
  "All Courses",
  "Development",
  "Design",
  "Marketing",
  "Business",
];

export default function CourseThreePage() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All Courses");
  const [sortBy, setSortBy] = useState("popular");

  const filteredCourses = useMemo(() => {
    const query = search.trim().toLowerCase();

    const result = courses.filter((course) => {
      const matchesCategory =
        category === "All Courses" || course.category === category;

      const matchesSearch = [
        course.title,
        course.category,
        course.instructor,
        course.level,
      ].some((value) => value.toLowerCase().includes(query));

      return matchesCategory && matchesSearch;
    });

    if (sortBy === "rating") {
      result.sort((a, b) => b.rating - a.rating);
    } else if (sortBy === "price-low") {
      result.sort((a, b) => a.price - b.price);
    } else if (sortBy === "price-high") {
      result.sort((a, b) => b.price - a.price);
    } else {
      result.sort((a, b) => b.students - a.students);
    }

    return result;
  }, [search, category, sortBy]);

  return (
    <main>
      <section className="bg-slate-50 py-16 sm:py-20">
        <Container>
          <div className="mx-auto max-w-3xl text-center">
            <p className="section-eyebrow">Discover your potential</p>
            <h1 className="section-title">
              Find the course that moves you forward
            </h1>
            <p className="section-description mt-4">
              Explore learning opportunities, compare courses, and choose
              a subject that matches your interests and goals.
            </p>

            <div className="mx-auto mt-8 flex max-w-xl items-center gap-3 rounded-xl border border-slate-200 bg-white px-4 py-3 shadow-sm">
              <Search size={20} className="shrink-0 text-slate-400" />
              <input
                type="search"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search courses, instructors, or levels..."
                aria-label="Search courses"
                className="w-full bg-transparent text-sm text-slate-800 outline-none placeholder:text-slate-400"
              />
            </div>
          </div>
        </Container>
      </section>

      <section className="section-padding bg-white">
        <Container>
          <SectionHeading
            eyebrow="Explore our catalog"
            title="Courses for every ambition"
            description="Choose a subject and discover courses designed for your learning journey."
          />

          <div className="mt-8 flex flex-wrap gap-3">
            {categories.map((item) => (
              <button
                key={item}
                type="button"
                aria-pressed={category === item}
                onClick={() => setCategory(item)}
                className={`rounded-full border px-5 py-2.5 text-sm font-semibold transition ${
                  category === item
                    ? "border-indigo-600 bg-indigo-600 text-white"
                    : "border-slate-200 text-slate-600 hover:border-indigo-300 hover:text-indigo-600"
                }`}
              >
                {item}
              </button>
            ))}
          </div>

          <div className="mt-8 flex flex-col gap-4 border-b border-slate-100 pb-5 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-sm text-slate-500">
              Showing{" "}
              <span className="font-semibold text-slate-900">
                {filteredCourses.length}
              </span>{" "}
              {filteredCourses.length === 1 ? "course" : "courses"}
            </p>

            <label className="flex items-center gap-3 text-sm text-slate-600">
              <SlidersHorizontal size={17} />
              Sort by
              <select
                value={sortBy}
                onChange={(event) => setSortBy(event.target.value)}
                className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-800 outline-none focus:border-indigo-500"
              >
                <option value="popular">Most popular</option>
                <option value="rating">Highest rated</option>
                <option value="price-low">Price: low to high</option>
                <option value="price-high">Price: high to low</option>
              </select>
            </label>
          </div>

          {filteredCourses.length > 0 ? (
            <div className="mt-7 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {filteredCourses.map((course) => (
                <article
                  key={course.id}
                  className="group overflow-hidden rounded-2xl border border-slate-100 bg-white transition duration-200 hover:-translate-y-1 hover:shadow-xl hover:shadow-slate-900/5"
                >
                  <div className="relative overflow-hidden">
                    <img
                      src={course.image}
                      alt={course.title}
                      loading="lazy"
                      className="aspect-[16/10] w-full object-cover transition duration-500 group-hover:scale-105"
                    />
                    <span className="absolute left-4 top-4 rounded-full bg-white px-3 py-1.5 text-xs font-semibold text-indigo-700 shadow-sm">
                      {course.category}
                    </span>
                  </div>

                  <div className="p-5">
                    <div className="flex items-center justify-between gap-3">
                      <span className="rounded-md bg-slate-50 px-2.5 py-1 text-xs font-medium text-slate-600">
                        {course.level}
                      </span>
                      <span className="inline-flex items-center gap-1 text-sm font-semibold text-amber-500">
                        <Star size={15} fill="currentColor" />
                        {course.rating.toFixed(1)}
                      </span>
                    </div>

                    <h2 className="mt-4 min-h-14 text-lg font-bold leading-7 text-slate-900 transition group-hover:text-indigo-600">
                      {course.title}
                    </h2>

                    <p className="mt-2 text-sm text-slate-500">
                      Instructor: {course.instructor}
                    </p>

                    <div className="mt-5 flex flex-wrap gap-x-4 gap-y-2 border-b border-slate-100 pb-5 text-xs text-slate-500">
                      <span className="inline-flex items-center gap-1.5">
                        <BookOpen size={15} />
                        {course.lessons} lessons
                      </span>
                      <span className="inline-flex items-center gap-1.5">
                        <Clock3 size={15} />
                        Self-paced
                      </span>
                      <span className="inline-flex items-center gap-1.5">
                        <Users size={15} />
                        {course.students.toLocaleString()} students
                      </span>
                    </div>

                    <div className="flex items-center justify-between gap-3 pt-5">
                      <span className="text-xl font-extrabold text-slate-900">
                        ${course.price.toFixed(2)}
                      </span>

                      <Link
                        to="/courses"
                        className="inline-flex items-center gap-1.5 text-sm font-semibold text-indigo-600 hover:text-indigo-800"
                      >
                        View course
                        <ArrowRight size={16} />
                      </Link>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <div className="mt-8 rounded-2xl border border-dashed border-slate-200 px-6 py-16 text-center">
              <h2 className="text-lg font-bold text-slate-900">
                No matching courses
              </h2>
              <p className="mt-2 text-sm text-slate-500">
                Try another search term or category.
              </p>
              <button
                type="button"
                onClick={() => {
                  setSearch("");
                  setCategory("All Courses");
                }}
                className="mt-5 rounded-lg bg-indigo-600 px-5 py-3 text-sm font-semibold text-white hover:bg-indigo-700"
              >
                Reset filters
              </button>
            </div>
          )}
        </Container>
      </section>
    </main>
  );
}
