
import { useMemo, useState } from "react";
import {
  ArrowRight,
  CalendarDays,
  Clock3,
  Search,
} from "lucide-react";
import Container from "../components/common/Container.jsx";
import SectionHeading from "../components/common/SectionHeading.jsx";

const articles = [
  {
    id: 1,
    title: "How to Build a Learning Habit That Actually Lasts",
    excerpt:
      "Discover practical strategies for creating a consistent learning routine and making progress even when life gets busy.",
    category: "Learning Tips",
    author: "Sarah Johnson",
    date: "October 12, 2026",
    readTime: "6 min read",
    image:
      "https://images.unsplash.com/photo-1455390582262-044cdead277a?auto=format&fit=crop&w=900&q=80",
  },
  {
    id: 2,
    title: "The Skills You Need to Succeed in the Digital World",
    excerpt:
      "Explore the essential digital skills that can help you adapt, solve problems, and grow your career in a changing workplace.",
    category: "Career",
    author: "Alex Morgan",
    date: "October 8, 2026",
    readTime: "8 min read",
    image:
      "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=900&q=80",
  },
  {
    id: 3,
    title: "A Beginner's Guide to Learning Web Development",
    excerpt:
      "Start your coding journey with a clear roadmap covering the foundations, useful tools, and your first project.",
    category: "Development",
    author: "James Parker",
    date: "October 3, 2026",
    readTime: "7 min read",
    image:
      "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=900&q=80",
  },
  {
    id: 4,
    title: "Simple Design Principles for Better User Experiences",
    excerpt:
      "Learn how hierarchy, spacing, color, and consistency help you create digital experiences that feel clear and intuitive.",
    category: "Design",
    author: "Olivia Bennett",
    date: "September 28, 2026",
    readTime: "5 min read",
    image:
      "https://images.unsplash.com/photo-1561070791-2526d30994b5?auto=format&fit=crop&w=900&q=80",
  },
  {
    id: 5,
    title: "How to Stay Motivated During an Online Course",
    excerpt:
      "Use manageable goals, progress tracking, and active practice to keep your momentum throughout an online course.",
    category: "Learning Tips",
    author: "Daniel Lewis",
    date: "September 22, 2026",
    readTime: "4 min read",
    image:
      "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&w=900&q=80",
  },
  {
    id: 6,
    title: "Turning Your Knowledge Into Career Opportunities",
    excerpt:
      "Find ways to showcase your new skills through projects, a portfolio, and thoughtful professional networking.",
    category: "Career",
    author: "David Wilson",
    date: "September 16, 2026",
    readTime: "6 min read",
    image:
      "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=900&q=80",
  },
];

const categories = [
  "All Articles",
  "Learning Tips",
  "Career",
  "Development",
  "Design",
];

export default function BlogTwoPage() {
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("All Articles");

  const filteredArticles = useMemo(() => {
    const query = search.trim().toLowerCase();

    return articles.filter((article) => {
      const matchesCategory =
        activeCategory === "All Articles" ||
        article.category === activeCategory;

      const searchableText = [
        article.title,
        article.excerpt,
        article.category,
        article.author,
      ]
        .join(" ")
        .toLowerCase();

      return matchesCategory && searchableText.includes(query);
    });
  }, [search, activeCategory]);

  const featuredArticle = articles[0];

  return (
    <main>
      <section className="bg-slate-50 py-16 sm:py-20 lg:py-24">
        <Container>
          <div className="mx-auto max-w-3xl text-center">
            <p className="section-eyebrow">Ideas that move you forward</p>

            <h1 className="section-title">
              Insights for your learning journey
            </h1>

            <p className="section-description mx-auto mt-4 max-w-2xl">
              Explore practical advice, fresh ideas, and helpful resources
              to support your personal and professional growth.
            </p>

            <div className="mx-auto mt-8 flex max-w-xl items-center gap-3 rounded-xl border border-slate-200 bg-white px-4 py-3 shadow-sm">
              <Search
                size={20}
                className="shrink-0 text-slate-400"
              />

              <input
                type="search"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search articles, topics, or authors..."
                aria-label="Search blog articles"
                className="w-full bg-transparent text-sm text-slate-800 outline-none placeholder:text-slate-400"
              />
            </div>
          </div>
        </Container>
      </section>

      {search.trim() === "" &&
        activeCategory === "All Articles" && (
          <section className="bg-white pt-12 sm:pt-16">
            <Container>
              <article className="grid overflow-hidden rounded-3xl border border-slate-100 bg-white shadow-sm md:grid-cols-2">
                <div className="min-h-64 overflow-hidden">
                  <img
                    src={featuredArticle.image}
                    alt={featuredArticle.title}
                    className="h-full min-h-64 w-full object-cover transition duration-500 hover:scale-105"
                  />
                </div>

                <div className="flex flex-col justify-center p-6 sm:p-9 lg:p-12">
                  <span className="w-fit rounded-full bg-indigo-50 px-3 py-1.5 text-xs font-bold text-indigo-700">
                    Featured article
                  </span>

                  <p className="mt-5 text-sm font-semibold text-indigo-600">
                    {featuredArticle.category}
                  </p>

                  <h2 className="mt-2 text-2xl font-bold leading-tight tracking-tight text-slate-900 sm:text-3xl">
                    {featuredArticle.title}
                  </h2>

                  <p className="mt-4 text-sm leading-7 text-slate-500">
                    {featuredArticle.excerpt}
                  </p>

                  <div className="mt-6 flex flex-wrap items-center gap-x-5 gap-y-3 text-xs text-slate-500">
                    <span>{featuredArticle.author}</span>

                    <span className="inline-flex items-center gap-1.5">
                      <CalendarDays size={14} />
                      {featuredArticle.date}
                    </span>
                  </div>

                  <a
                    href="#all-articles"
                    className="mt-7 inline-flex w-fit items-center gap-2 rounded-lg bg-indigo-600 px-5 py-3 text-sm font-semibold text-white transition hover:bg-indigo-700"
                  >
                    Explore articles
                    <ArrowRight size={17} />
                  </a>
                </div>
              </article>
            </Container>
          </section>
        )}

      <section
        id="all-articles"
        className="section-padding bg-white"
      >
        <Container>
          <SectionHeading
            eyebrow="From our blog"
            title="Explore our latest articles"
            description="Find inspiration, develop new skills, and discover ideas you can put into practice."
          />

          <div className="mt-8 flex flex-wrap gap-3">
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                aria-pressed={activeCategory === category}
                onClick={() => setActiveCategory(category)}
                className={`rounded-full border px-4 py-2.5 text-sm font-semibold transition ${
                  activeCategory === category
                    ? "border-indigo-600 bg-indigo-600 text-white"
                    : "border-slate-200 bg-white text-slate-600 hover:border-indigo-300 hover:text-indigo-600"
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          <div className="mt-7 flex items-center justify-between border-b border-slate-100 pb-4">
            <p className="text-sm text-slate-500">
              Showing{" "}
              <span className="font-semibold text-slate-900">
                {filteredArticles.length}
              </span>{" "}
              {filteredArticles.length === 1 ? "article" : "articles"}
            </p>

            {(search || activeCategory !== "All Articles") && (
              <button
                type="button"
                onClick={() => {
                  setSearch("");
                  setActiveCategory("All Articles");
                }}
                className="text-sm font-semibold text-indigo-600 hover:text-indigo-800"
              >
                Clear filters
              </button>
            )}
          </div>

          {filteredArticles.length > 0 ? (
            <div className="mt-7 grid gap-7 sm:grid-cols-2 lg:grid-cols-3">
              {filteredArticles.map((article) => (
                <article
                  key={article.id}
                  className="group overflow-hidden rounded-2xl border border-slate-100 bg-white transition duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-slate-900/5"
                >
                  <div className="relative overflow-hidden">
                    <img
                      src={article.image}
                      alt={article.title}
                      loading="lazy"
                      className="aspect-[16/10] w-full object-cover transition duration-500 group-hover:scale-105"
                    />

                    <span className="absolute left-4 top-4 rounded-full bg-white px-3 py-1.5 text-xs font-semibold text-indigo-700 shadow-sm">
                      {article.category}
                    </span>
                  </div>

                  <div className="p-5 sm:p-6">
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-slate-500">
                      <span className="inline-flex items-center gap-1.5">
                        <CalendarDays size={14} />
                        {article.date}
                      </span>

                      <span className="inline-flex items-center gap-1.5">
                        <Clock3 size={14} />
                        {article.readTime}
                      </span>
                    </div>

                    <h2 className="mt-4 text-xl font-bold leading-7 text-slate-900 transition group-hover:text-indigo-600">
                      {article.title}
                    </h2>

                    <p className="mt-3 text-sm leading-7 text-slate-500">
                      {article.excerpt}
                    </p>

                    <div className="mt-5 flex items-center justify-between gap-3 border-t border-slate-100 pt-5">
                      <span className="text-sm font-medium text-slate-600">
                        {article.author}
                      </span>

                      <a
                        href="#all-articles"
                        className="inline-flex shrink-0 items-center gap-1.5 text-sm font-semibold text-indigo-600 hover:text-indigo-800"
                      >
                        Read article
                        <ArrowRight size={16} />
                      </a>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <div className="mt-8 rounded-2xl border border-dashed border-slate-200 px-6 py-16 text-center">
              <h2 className="text-lg font-bold text-slate-900">
                No articles found
              </h2>

              <p className="mt-2 text-sm text-slate-500">
                Try another keyword or choose a different category.
              </p>

              <button
                type="button"
                onClick={() => {
                  setSearch("");
                  setActiveCategory("All Articles");
                }}
                className="mt-5 rounded-lg bg-indigo-600 px-5 py-3 text-sm font-semibold text-white transition hover:bg-indigo-700"
              >
                Show all articles
              </button>
            </div>
          )}
        </Container>
      </section>
    </main>
  );
}
