
export const navigation = [
  {
    label: "Home",
    href: "/",
    children: [
      { label: "Home One", href: "/" },
      { label: "Home Two", href: "/" },
      { label: "Home Three", href: "/" },
    ],
  },
  {
    label: "Courses",
    href: "/courses",
    children: [
      {
        label: "Free Courses",
        href: "/courses",
        description: "Free learning resources for skill development.",
      },
      {
        label: "Paid Courses",
        href: "/courses",
        description: "Explore courses available upon purchase.",
      },
      {
        label: "Finance",
        href: "/courses",
        items: [
          {
            label: "Understanding Corporate Finance and Investments",
            href: "/courses",
          },
          {
            label: "Personal and Business Finance",
            href: "/courses",
          },
        ],
      },
      {
        label: "Design",
        href: "/courses",
        items: [
          {
            label: "Advanced Photoshop Techniques",
            href: "/courses",
          },
          {
            label: "Web Design Projects",
            href: "/courses",
          },
        ],
      },
      {
        label: "Management",
        href: "/courses",
        items: [
          {
            label: "Crisis Management and Problem Solving",
            href: "/courses",
          },
          {
            label: "Risk Management and Business Continuity",
            href: "/courses",
          },
        ],
      },
      {
        label: "Development",
        href: "/courses",
        items: [
          {
            label: "Building Single Page Applications",
            href: "/courses",
          },
          {
            label: "Database Integration with MongoDB",
            href: "/courses",
          },
          {
            label: "Full-Stack Development with MERN",
            href: "/courses",
          },
        ],
      },
    ],
  },
  {
    label: "Pages",
    href: "/courses",
    children: [
      { label: "About One", href: "/courses" },
      { label: "About Two", href: "/courses" },
      { label: "Course One", href: "/courses" },
      { label: "Course Two", href: "/courses" },
      { label: "Course Three", href: "/course-3" },
      { label: "FAQ", href: "/courses" },
      { label: "Pricing One", href: "/courses" },
      { label: "Pricing Two", href: "/courses" },
      { label: "Pricing Three", href: "/courses" },
      { label: "Career", href: "/courses" },
      { label: "Events", href: "/courses" },
      { label: "Team", href: "/courses" },
    ],
  },
  {
    label: "Blog",
    href: "/blog-2",
    children: [
      { label: "Blog One", href: "/blog-2" },
      { label: "Blog Two", href: "/blog-2" },
      { label: "Blog Three", href: "/blog-2" },
    ],
  },
  {
    label: "Contact",
    href: "/contact-1",
    children: [
      { label: "Contact One", href: "/contact-1" },
      { label: "Contact Two", href: "/contact-1" },
      { label: "Contact Three", href: "/contact-1" },
    ],
  },
];
